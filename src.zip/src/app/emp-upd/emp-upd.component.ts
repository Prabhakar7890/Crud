import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emp-upd',
  templateUrl: './emp-upd.component.html',
  styleUrls: ['./emp-upd.component.css']
})
export class EmpUpdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
